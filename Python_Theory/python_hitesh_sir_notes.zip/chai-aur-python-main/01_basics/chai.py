from hello_chai import chai

chai("ginger tea")

# this is comment