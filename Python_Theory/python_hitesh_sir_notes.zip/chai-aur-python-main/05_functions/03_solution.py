def multiply(p1, p2):
    return p1 * p2


print(multiply(8, 5))
print(multiply('a', 5))
print(multiply(5, 'a'))