# welcome to the python series | chai aur python

Hanji, ye python ki series hai, jisme hum python ke bare me seekhenge. Ye series hindi me hai, jisse aapko samajhne me aasani hogi. Ye series kuch is tarah se hogi ki ab aapko python ko samajhne me koi dikkat nahi hogi. Is series me hum python ke basics se lekar advance tak ke topics cover karenge. Bht saara behind the scenes bhi seekhne ko milega. Toh chaliye shuru karte hai.

## Youtube
series aapko "chai aur code" youtube channel pe milegi. 

## PR
Please isme koi PR request na kare. 

## Support
[Discord](https://hitesh.ai/discord)

## Whatsapp
[Whatsapp](https://hitesh.ai/whatsapp)